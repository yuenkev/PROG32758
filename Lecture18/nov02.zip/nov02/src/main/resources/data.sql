INSERT INTO users
    (name, email, address)
VALUES
    ('Joe', 'joe@email.com', '123 Joe St.'),
    ('Bob', 'bob@email.com', '123 Bob St.');
