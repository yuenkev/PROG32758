package com.example.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@Controller
public class DemoController {

        @GetMapping("/register")
        public String registerUser(
                @RequestParam String firstName,
                @RequestParam String lastName,
                        //the default value is always the same if u check the box (on = always on, off = always off)
                        @RequestParam(defaultValue="on") String rememberMe){
                System.out.println(firstName + " " + lastName + " " + rememberMe);
                return "success";
        }

        @GetMapping("/register_page")
        public String goRegister(){
                return "register";
        }


}

