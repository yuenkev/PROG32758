package ca.sheridancollege.fragments.example.beans;

import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Data
public class Student {

    private Long id;
    private String userName;
}
