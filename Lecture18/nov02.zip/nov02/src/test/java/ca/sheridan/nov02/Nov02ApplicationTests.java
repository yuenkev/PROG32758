package ca.sheridan.nov02;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Nov02ApplicationTests {

	@Test
	void contextLoads() {
	}

}
