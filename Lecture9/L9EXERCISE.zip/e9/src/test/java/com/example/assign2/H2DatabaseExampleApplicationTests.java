package com.example.assign2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import java.sql.Time;
import java.time.LocalDate;
import java.time.LocalDateTime;

@SpringBootTest
class H2DatabaseExampleApplicationTests {

	@Test
	void contextLoads() {
	}

//	@Test
//	void seeDataType(){
//
//		System.out.println(LocalDateTime.now());
//	}

}
