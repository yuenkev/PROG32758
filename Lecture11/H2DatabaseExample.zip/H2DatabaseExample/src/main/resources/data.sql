INSERT INTO avengers
    (name, age)
VALUES
    ('Thor',32), ('Nebula',28);