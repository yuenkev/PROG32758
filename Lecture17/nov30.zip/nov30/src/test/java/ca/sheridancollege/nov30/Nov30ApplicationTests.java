package ca.sheridancollege.nov30;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Nov30ApplicationTests {

	@Test
	void contextLoads() {
	}

}
