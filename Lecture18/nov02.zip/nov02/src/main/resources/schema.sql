CREATE TABlE users
(
    id      LONG PRIMARY KEY AUTO_INCREMENT,
    name    VARCHAR(200),
    email   VARCHAR(200),
    address VARCHAR(200)
);