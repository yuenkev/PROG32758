CREATE TABLE avengers(
    id LONG PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(50),
    age INT
);