CREATE TABLE students(
    id LONG PRIMARY KEY AUTO_INCREMENT,
    fName VARCHAR(50),
    lName VARCHAR(50),
    program VARCHAR(50),
    sYear int,
    opts VARCHAR(50)

);