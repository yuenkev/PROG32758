CREATE TABLE students(
    id LONG PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(255)
);

    INSERT INTO students (username) VALUES
            ('Iron Man'), ('Black Widow');
