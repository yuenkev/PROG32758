package ca.sheridancollege.nov30;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Nov30Application {

	public static void main(String[] args) {
		SpringApplication.run(Nov30Application.class, args);
	}

}
