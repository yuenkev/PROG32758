INSERT INTO students
    (fNAme, lName, program, sYear, opts)
VALUES
    ('Thor', 'Odinson', 'Science', 2, 'Co-op');